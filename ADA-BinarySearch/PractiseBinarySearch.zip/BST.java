
public class BST {
	private BSTNode root;

	 /* Constructor */
    public BST()
    {
    }
    /* Function to check if tree is empty */
    public boolean isEmpty()
    {
    }
    /* Functions to insert data */
    public void insert(int data)
    {
    }
    /* Function to insert data recursively */
    private BSTNode insert(BSTNode node, int data)
    {
    }
    /* Functions to delete data */
    public void delete(int k)
    {
       
    }
    private BSTNode delete(BSTNode root, int k)
    {
      
    }
    /* Functions to count number of nodes */
    public int countNodes()
    {
    }
    /* Function to count number of nodes recursively */
    private int countNodes(BSTNode r)
    {
        
    }
    /* Functions to search for an element */
    public boolean search(int val)
    {
    }
    /* Function to search for an element recursively */
    private boolean search(BSTNode r, int val)
    {
       
    }
    /* Function for inorder traversal */
    public void inorder()
    {
    }
    private void inorder(BSTNode r)
    {
        
    }
    /* Function for preorder traversal */
    public void preorder()
    {
    }
    private void preorder(BSTNode r)
    {
       
    }
    /* Function for postorder traversal */
    public void postorder()
    {
    }
    private void postorder(BSTNode r)
    {

    }     
}


public class BSTNode {
	
	 private BSTNode left, right;
     private int data;
 
     /* Constructor */
     public BSTNode()
     {
        
     }
     /* Constructor */
     public BSTNode(int n)
     {
       
     }
     
     /* SETTERS Function to set left node */
     public void setLeft(BSTNode n)
     {
        
     }
     /* Function to set right node */ 
     public void setRight(BSTNode n)
     {
     }
   
     
     /* GETTERS Function to get left node */
     public BSTNode getLeft()
     {
     }
     /* Function to get right node */
     public BSTNode getRight()
     {
     }
     
     /* GETTERS AND SETTERS For data Function to set data to node */
     public void setData(int d)
     {
     }
     /* Function to get data from node */
     public int getData()
     {
     }     
}

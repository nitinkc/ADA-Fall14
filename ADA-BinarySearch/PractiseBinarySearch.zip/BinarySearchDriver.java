import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * Implementing the Binary search tree
 */

/**
 * @author nitin
 * Wednesday Oct 29
 *
 */
public class BinarySearchDriver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		File file = new File("data.txt");
		Scanner inputFile = null;
		try {
			inputFile = new Scanner(file);
		} catch (FileNotFoundException e) {
			//System.out.println("Where is the File??");
			e.printStackTrace();
		}
		
		while (inputFile.hasNext()){
			int val = inputFile.nextInt();
			System.out.println(val);
			
		}
		
		//Close the File
		inputFile.close();

	}

}
